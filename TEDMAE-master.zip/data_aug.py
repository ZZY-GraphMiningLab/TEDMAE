#includes four kinds of data augmentation
import torch

import torch
import copy
import random
import pdb
import scipy.sparse as sp
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def mask_hard_feature(x, edge, node_p, type):
    src_features = x[edge[0], :]
    dst_features = x[edge[1], :]

    # 计算余弦相似度
    cosine_similarity0 = cosine_similarity(src_features.cpu().numpy(), dst_features.cpu().numpy())
    connected_pairs_similarity = np.diag(cosine_similarity0)

    # 根据type选择阈值
    threshold = 0.7 if type == "homo" else 0.3

    # 找到超过阈值的相似度索引
    high_similarity_indices = np.where(connected_pairs_similarity > threshold)[0]

    # 获取超过阈值的源节点和目标节点索引
    high_similarity_src_indices = edge[0, high_similarity_indices]
    high_similarity_dst_indices = edge[1, high_similarity_indices]

    # 合并并去重源节点和目标节点索引
    unique_indices = torch.cat((high_similarity_src_indices, high_similarity_dst_indices), dim=0).unique()

    # 将超过阈值的节点特征置零
    x[unique_indices, :] = 0

    # 创建掩码
    mask = torch.zeros((x.size(0),), dtype=torch.bool, device=x.device)
    mask[unique_indices] = True

    return x, mask



def mask_feature(x, node_p):

    #maks node_p% node
    mask = torch.empty((x.size(0), ), dtype=torch.float32, device=x.device).uniform_(0, 1) < node_p
    x = x.clone()
    x[mask,:] = 0

    return x, mask


def filter_adj(row, col, mask):
    return row[mask], col[mask]
      

def dropout_edge(edge_index, edge_p):
    #drop edge_p% edge

    row, col = edge_index
    p = torch.zeros(edge_index.shape[1]).to(edge_index.device) + 1 - edge_p
    stay = torch.bernoulli(p).to(torch.bool)
    mask = ~stay
    row, col = filter_adj(row, col, stay)
    edge_index = torch.stack([row, col], dim=0)

    return edge_index.long(), mask

import torch as th
import numpy as np
import dgl

def aug(data, x, feat_drop_rate, edge_mask_rate):
    n_node = x.shape[0]

    edge_mask = mask_edge(data, edge_mask_rate)
    feat = drop_feature(x, feat_drop_rate)

    src = data.edge_index[0]
    dst = data.edge_index[1]

    nsrc = src[edge_mask]
    ndst = dst[edge_mask]

    ng = dgl.graph((nsrc, ndst), num_nodes=n_node)
    ng = ng.add_self_loop()

    return ng, feat

def drop_feature(x, drop_prob):
    drop_mask = th.empty((x.size(1),),
                        dtype=th.float32,
                        device=x.device).uniform_(0, 1) < drop_prob
    x = x.clone()
    x[:, drop_mask] = 0

    return x

def mask_edge(graph, mask_prob):
    E = graph.edge_index.shape[1]

    mask_rates = th.FloatTensor(np.ones(E) * mask_prob)
    masks = th.bernoulli(1 - mask_rates)
    mask_idx = masks.nonzero().squeeze(1)
    return mask_idx
