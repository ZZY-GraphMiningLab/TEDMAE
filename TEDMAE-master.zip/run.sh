# node label_classification
python -u main.py --dataset Cora   --lr 0.001  --epoch 300  --ratio 0.3 --gpu_num cuda:0 --edge_p1 0.7 --edge_p2 0.5 --u 0.8 --v 0.8 --tau 0.7 --hidden_num 64 --out_channels 512 --head 4 --seed 6
python -u main.py --dataset WikiCS --lr 0.001  --epoch 200  --ratio 0.8 --gpu_num cuda:0 --edge_p1 0.5 --edge_p2 0.5 --u 0.8 --v 0.8 --tau 0.1 --hidden_num 64 --out_channels 512 --head 4 --seed 3
python -u main.py --dataset Amazon-Photo     --lr 0.015  --epoch 6000   --ratio 0.8 --gpu_num cuda:0  --edge_p1 0.2 --edge_p2 0.2 --tau 0.7 --hidden_num 16 --out_channels 256 --head 4 --walk_length 10 --context_size 10 --walks_per_node 10 --node2vec_lr 0.1  --node2vec_epoch 100 --node2vec_neg_samples 10 --node2vec_batchsize 4096  --lrdec_2 10000 --seed 9
python -u main.py --dataset Amazon-Computers     --lr 0.005  --epoch 1000  --ratio 0.5 --gpu_num cuda:0  --edge_p1 0.4  --margin_hom 0.2 --edge_p2 0.3 --u 0.8 --v 0.8 --tau 0.7 --hidden_num 64 --out_channels 512 --head 4 --walk_length 10 --context_size 10 --walks_per_node 10 --node2vec_lr 0.1  --node2vec_epoch 30 --node2vec_neg_samples 10 --node2vec_batchsize 4096  --seed 4
python -u main.py --dataset Coauthor-CS   --lr 0.0001  --epoch 400  --ratio 1 --gpu_num cuda:0 --node_p 0.2   --tau 0.1  --hidden_num 32 --out_channels 512 --head 16 --walk_length 10 --context_size 10 --walks_per_node 10 --node2vec_lr 0.1  --node2vec_epoch 200 --node2vec_neg_samples 10 --node2vec_batchsize 4096
python -u main.py --dataset Coauthor-Phy   --lr 0.0005 --epoch 100  --ratio 1 --gpu_num cuda:0   --tau 0.1 --hidden_num 16 --out_channels 512 --head 32  --walk_length 10 --context_size 10 --walks_per_node 10 --node2vec_lr 0.1  --node2vec_epoch 200 --node2vec_neg_samples 10 --node2vec_batchsize 4096  --seed 7
python -u main.py --dataset arxiv --lr 0.001  --epoch 300  --ratio 0.3 --gpu_num cuda:0 --edge_p1 0.7 --edge_p2 0.5 --u 0.8 --v 0.8 --tau 0.7 --hidden_num 64 --out_channels 512 --head 4 --seed 6

# node cluster
python -u main.py --dataset Cora   --lr 0.001  --epoch 300  --ratio 0.3 --gpu_num cuda:0 --edge_p1 0.7 --edge_p2 0.5 --u 0.8 --v 0.8 --tau 0.7 --hidden_num 64 --out_channels 512 --head 4 --seed 6


