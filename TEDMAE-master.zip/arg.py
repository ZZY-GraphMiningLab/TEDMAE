import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default = 6)
parser.add_argument('--dataset', type=str, default='Cora')
parser.add_argument('--gpu_num', type=str, default='cpu')
parser.add_argument('--linear', type=bool, default=False)
parser.add_argument('--embedding_train', type=bool, default = True)
parser.add_argument('--teacher_eval', type=bool, default = False)

parser.add_argument('--margin_hom', type=float, default=0.5)
parser.add_argument('--margin_het', type=float, default=0.5)

parser.add_argument('--node_p', type=float, default=0.1)
parser.add_argument('--edge_p1', type=float, default=0.7)
parser.add_argument('--edge_p2', type=float, default=0.3)

parser.add_argument('--u', type=float, default=0.8)
parser.add_argument('--v', type=float, default=0.2)

parser.add_argument('--epoch', type=int, default=10000)
parser.add_argument('--lrdec_1', type=float, default=0.8)
parser.add_argument('--lrdec_2', type=int, default=200)
parser.add_argument('--lr', type=float, default=0.01)
parser.add_argument('--dropout', type=float, default=0.6)
parser.add_argument('--test', type=int, default=10000)
parser.add_argument('--tau', type=float, default=0.5)
parser.add_argument('--hidden_num', type=int, default = 64)
parser.add_argument('--head', type=int, default = 4)
parser.add_argument('--out_channels', type=int, default = 512)
parser.add_argument('--write', type=int, default = 0)
parser.add_argument('--ratio', type=float, default=0.3)
parser.add_argument('--batch_size', type=int, default=128)
parser.add_argument('--patience', type=int, default = 1000)

parser.add_argument('--embedding_dim', type=int, default = 64)
parser.add_argument('--walk_length', type=int, default = 5)
parser.add_argument('--context_size', type=int, default = 5)
parser.add_argument('--walks_per_node', type=int, default = 5)
parser.add_argument('--node2vec_batchsize', type=int, default = 512)
parser.add_argument('--node2vec_epoch', type=int, default = 100)
parser.add_argument('--node2vec_lr', type=float, default = 0.01)
parser.add_argument('--node2vec_neg_samples', type=int, default = 5)
parser.add_argument('--p', type=float, default = 1)
parser.add_argument('--q', type=float, default = 1)


parser.add_argument('--type1', type=str, default='homo')
parser.add_argument('--type2', type=str, default='heter')

parser.add_argument('--ntrials', type=int, default = 10)


parser.add_argument('--split', type=str, default='random')

parser.add_argument('--epochs', type=int, default=500, help='Number of training periods.')
parser.add_argument('--tlr', type=float, default=0.001, help='Learning rate.')
parser.add_argument('--wd', type=float, default=1e-5, help='Weight decay.')
parser.add_argument('--temp', type=float, default=1.0, help='Temperature.')

parser.add_argument('--act_fn', type=str, default='relu')

parser.add_argument("--hid_dim", type=int, default=256, help='Hidden layer dim.')
parser.add_argument("--out_dim", type=int, default=128, help='Output layer dim.')

parser.add_argument("--num_layers", type=int, default=2, help='Number of GNN layers.')
parser.add_argument('--der1', type=float, default=0.2, help='Drop edge ratio of the 1st augmentation.')
parser.add_argument('--der2', type=float, default=0.2, help='Drop edge ratio of the 2nd augmentation.')
parser.add_argument('--dfr1', type=float, default=0.2, help='Drop feature ratio of the 1st augmentation.')
parser.add_argument('--dfr2', type=float, default=0.2, help='Drop feature ratio of the 2nd augmentation.')

    
args = parser.parse_args()