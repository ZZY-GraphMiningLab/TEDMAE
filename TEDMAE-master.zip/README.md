# TEDMAE
This is the source code of AAAI'25 paper "Teacher-guided Edge Discriminator for Personalized Graph Masked Autoencoder".

## Requirements
This code requires the following:
* Python==3.10
* Pytorch==1.12.0


## Usage
Just run the script corresponding to the dataset you want. For instance:

```
run.sh
```

## Cite

If you compare with, build on, or use aspects of this work, please cite the following:
```
@inproceedings{
TEDMAE,
title={Teacher-guided Edge Discriminator for Personalized Graph Masked Autoencoder},
author={Zhang, Qiqi and Li, Chao and Zhao, Zhongying},
booktitle={AAAI},
year={2025}
}
```
