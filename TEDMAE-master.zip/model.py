import torch
import torch.nn as nn
from arg import args
import torch.nn.functional as F
from torch_geometric.nn import GAE, VGAE, GATConv, BatchNorm, GCNConv
import dgl
from dgl.nn import EdgeWeightNorm


EOS = 1e-10
norm = EdgeWeightNorm(norm='both')

def sce_loss(x, y, alpha=3):
    x = F.normalize(x, p=2, dim=-1)
    y = F.normalize(y, p=2, dim=-1)
    # loss =  - (x * y).sum(dim=-1)
    # loss = (x_h - y_h).norm(dim=1).pow(alpha)

    loss = (1 - (x * y).sum(dim=-1)).pow_(alpha)

    loss = loss.mean()
    return loss


class prediction_MLP(nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim): # bottleneck structure
        super().__init__()

        self.layer1 = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True)
        )
        self.layer2 = nn.Linear(hidden_dim, out_dim)
        
    def forward(self, x):
        
        x = self.layer1(x)
        x = self.layer2(x)
        return x


class Attention(nn.Module):
    def __init__(self, in_size, hidden_size=16):
        super(Attention, self).__init__()

        self.project = nn.Sequential(
            nn.Linear(in_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        w = self.project(z)
        beta = torch.softmax(w, dim=1)
        return (beta * z).sum(1), beta

class GAE(torch.nn.Module):
    def __init__(self, in_channels, hidden_num, head,  out_channels, emb_size_1,emb_size_2, activation, base_model=GATConv):
        super().__init__()
        self.base_model = base_model

        self.conv1 = base_model(in_channels, hidden_num, heads=head, dropout=args.dropout)
        self.conv2 = base_model(hidden_num * head, out_channels, heads=1, concat=False,dropout=args.dropout)

        self.conv3 = base_model(in_channels, hidden_num, heads=head, dropout=args.dropout)
        self.conv4 = base_model(hidden_num * head, out_channels, heads=1, concat=False,dropout=args.dropout)
        
        self.bn1 = BatchNorm(hidden_num * head, momentum=0.99)
        self.bn2 = BatchNorm(out_channels, momentum=0.99)

        self.p_1 = prediction_MLP(out_channels, out_channels*2, emb_size_1)
        self.p_2 = prediction_MLP(out_channels, out_channels*2, emb_size_2)
        self.p = nn.Linear(out_channels, in_channels, bias=False)

        self.activation = activation

        self.attention = Attention(out_channels)
        self.MLP = nn.Sequential(
            nn.Linear(out_channels, out_channels),
            nn.LogSoftmax(dim=1)
        )
        
    def encoder1(self, x, edge_index):
        
        x = F.dropout(x, p=args.dropout, training=self.training)
        x = self.activation(self.bn1(self.conv1(x, edge_index)))
        x = F.dropout(x, p=args.dropout, training=self.training)
        x = self.activation(self.conv2(x, edge_index))

        return x

    def encoder2(self, x, edge_index):
        x = F.dropout(x, p=args.dropout, training=self.training)
        x = self.activation(self.bn1(self.conv3(x, edge_index)))
        x = F.dropout(x, p=args.dropout, training=self.training)
        x = self.activation(self.conv4(x, edge_index))

        return x
    
    
    def decoder_all(self, z):

        recon_emb_1 = self.p_1(z)
        recon_emb_2 = self.p_2(z)

        recon_x = self.p(z)

        return recon_emb_1, recon_emb_2, recon_x

    def enc_dec(self, x1, mask_adj1, x2, mask_adj2):

        x1 = self.encoder1(x1, mask_adj1)
        x2 = self.encoder2(x2, mask_adj2)

        recon_11, recon_12, recon_x1= self.decoder_all(x1)
        recon_21, recon_22, recon_x2 = self.decoder_all(x2)
        # recon1 = recon_11 + recon_21
        # recon2 = recon_21 + recon_22

        return recon_11, recon_12, recon_21,recon_22, recon_x1+recon_x2


    
    def forward(self, x: torch.Tensor, edge_index: torch.Tensor):

        z1 = self.encoder1(x, edge_index)
        z2 = self.encoder2(x, edge_index)

        emb = torch.stack([z1, z2], dim=1)
        emb, att = self.attention(emb)
        # emb, att  = self.MLP(emb)

        return emb


def get_adj_from_edges(edges, weights, nnodes):
    adj = torch.zeros(nnodes, nnodes)
    adj[edges[0], edges[1]] = weights
    return adj


def sim(z1, z2):
    z1 = F.normalize(z1)
    z2 = F.normalize(z2)
    return torch.mm(z1, z2.t())


def normalize_adj(adj, mode, sparse=False):
    if not sparse:
        if mode == "sym":
            inv_sqrt_degree = 1. / (torch.sqrt(adj.sum(dim=1, keepdim=False)) + EOS)
            return inv_sqrt_degree[:, None] * adj * inv_sqrt_degree[None, :]
        elif mode == "row":
            inv_degree = 1. / (adj.sum(dim=1, keepdim=False) + EOS)
            return inv_degree[:, None] * adj
        else:
            exit("wrong norm mode")
    else:
        adj = adj.coalesce()
        if mode == "sym":
            inv_sqrt_degree = 1. / (torch.sqrt(torch.sparse.sum(adj, dim=1).values()))
            D_value = inv_sqrt_degree[adj.indices()[0]] * inv_sqrt_degree[adj.indices()[1]]

        elif mode == "row":
            inv_degree = 1. / (torch.sparse.sum(adj, dim=1).values() + EOS)
            D_value = inv_degree[adj.indices()[0]]
        else:
            exit("wrong norm mode")
        new_values = adj.values() * D_value

        return torch.sparse.FloatTensor(adj.indices(), new_values, adj.size())

class New_EdgeDiscriminator(nn.Module):
    def __init__(self, nnodes, input_dim, alpha, sparse, hidden_dim=128, temperature=0.5, bias=0.0 + 0.0001,tau: float=0.5):
        super(New_EdgeDiscriminator, self).__init__()
        self.embedding_layers = nn.ModuleList()
        self.embedding_layers.append(nn.Linear(input_dim, hidden_dim))
        self.edge_mlp = nn.Linear(hidden_dim * 2, 1)
        self.temperature = temperature
        self.bias = bias
        self.nnodes = nnodes
        self.sparse = sparse
        self.alpha = alpha
        self.tau: float = tau

    def get_node_embedding(self, h):
        for layer in self.embedding_layers:
            h = layer(h)
            h = F.relu(h)
        return h

    def get_edge_weight(self, embeddings, edges):
        s1 = self.edge_mlp(torch.cat((embeddings[edges[0]], embeddings[edges[1]]), dim=1)).flatten()
        s2 = self.edge_mlp(torch.cat((embeddings[edges[1]], embeddings[edges[0]]), dim=1)).flatten()
        return (s1 + s2) / 2

    def concrete_sampling(self, edges_weights_raw, temperature, hard=False):
        gumbel_noise = -torch.log(-torch.log(torch.rand_like(edges_weights_raw)))
        y = (edges_weights_raw + gumbel_noise) / temperature
        concrete_dist = F.softmax(y, dim=0)
        if hard:
            _, k = concrete_dist.max(0)
            hard_samples = torch.zeros_like(concrete_dist).scatter_(0, k.view(-1), 1)
            concrete_dist = concrete_dist + (hard_samples - concrete_dist).detach()

        return concrete_dist

    def weight_forward(self, features, edges, hard=False):
        # Get node embeddings
        embeddings = self.get_node_embedding(features)
        edges_weights_raw = self.get_edge_weight(embeddings, edges)
        concrete_dist = self.concrete_sampling(edges_weights_raw, self.temperature, hard)
        weights_lp = concrete_dist
        weights_hp = 1 - weights_lp
        return weights_lp, weights_hp

    def generate_homophily_edges(self, homophily_probs, edges):
        # Assuming concrete_dist are probabilities of homophily
        _, homophily_edges = torch.topk(homophily_probs, k=int(args.u*edges.shape[1]), dim=0)
        return edges[:, homophily_edges]

    def generate_heterophily_edges(self, heterophily_probs, edges):
        # Assuming concrete_dist are probabilities of heterophily
        _, heterophily_edges = torch.topk(heterophily_probs, k=int(args.v*edges.shape[1]), dim=0)
        return edges[:, heterophily_edges]


    def forward(self, features, edges):
        homophily_probs, heterophily_probs = self.weight_forward(features, edges)
        homophily_edges = self.generate_homophily_edges(homophily_probs, edges)
        heterophily_edges = self.generate_heterophily_edges(heterophily_probs, edges)
        return homophily_edges, heterophily_edges,homophily_probs