# -- coding: utf-8 --
import os
import os.path as osp
import random
import numpy as np
from time import perf_counter as t

import torch
import torch.nn.functional as F
from torch_geometric.nn import GAE, GATConv

from arg import args
from data_aug import mask_feature, dropout_edge,mask_hard_feature
from eval import label_classification, clustering
from teacher import PCA, node2vec
from datasets import get_dataset
from model import GAE, New_EdgeDiscriminator



def seed_torch(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def generate_random_node_pairs(nnodes, nedges, backup=300):
    rand_edges = np.random.choice(nnodes, size=(nedges + backup) * 2, replace=True)
    rand_edges = rand_edges.reshape((2, nedges + backup))
    rand_edges = torch.from_numpy(rand_edges)
    rand_edges = rand_edges[:, rand_edges[0, :] != rand_edges[1, :]]
    rand_edges = rand_edges[:, 0: nedges]
    return rand_edges.cuda()


def train_discriminator(discriminator, optimizer_disc, features, edges, PCA_teacher, node2vec_teacher, args):
    discriminator.train()

    home_edge, heter_edge, concrete_dist = discriminator(features, edges)
    rand_np = generate_random_node_pairs(features.shape[0], edges.shape[1]).type(torch.long)
    psu_label = torch.ones(edges.shape[1]).cuda()

    embedding1 = PCA_teacher
    embedding2 = node2vec_teacher

    edge_emb_sim = F.cosine_similarity(embedding1[edges[0]], embedding1[edges[1]])

    rnp_emb_sim_lp = F.cosine_similarity(embedding1[rand_np[0]], embedding1[rand_np[1]])
    loss_lp1 = F.margin_ranking_loss(edge_emb_sim, rnp_emb_sim_lp, psu_label, margin=args.margin_hom, reduction='none')
    loss_lp1 *= torch.relu(concrete_dist)

    rnp_emb_sim_hp = F.cosine_similarity(embedding1[rand_np[0]], embedding1[rand_np[1]])
    loss_hp1 = F.margin_ranking_loss(rnp_emb_sim_hp, edge_emb_sim, psu_label, margin=args.margin_het, reduction='none')
    loss_hp1 *= torch.relu(1-concrete_dist)

    edge_emb_sim = F.cosine_similarity(embedding2[edges[0]], embedding2[edges[1]])

    rnp_emb_sim_lp = F.cosine_similarity(embedding2[rand_np[0]], embedding2[rand_np[1]])
    loss_lp2 = F.margin_ranking_loss(edge_emb_sim, rnp_emb_sim_lp, psu_label, margin=args.margin_hom, reduction='none')
    loss_lp2 *= torch.relu(concrete_dist)

    rnp_emb_sim_hp = F.cosine_similarity(embedding2[rand_np[0]], embedding2[rand_np[1]])
    loss_hp2 = F.margin_ranking_loss(rnp_emb_sim_hp, edge_emb_sim, psu_label, margin=args.margin_het, reduction='none')
    loss_hp2 *= torch.relu(1-concrete_dist)

    rank_loss = (loss_lp1.mean() + loss_lp2.mean() + loss_hp1.mean() + loss_hp2.mean()) / 2
    optimizer_disc.zero_grad()
    rank_loss.backward()
    optimizer_disc.step()

    return rank_loss.item()


def pretrain(discriminator, optimizer_disc, x, edge_index, args):
    print('Start pretrain')
    emb_node2vec = node2vec(data)
    emb_pca = PCA(data.x, args.ratio)

    for epoch in range(100):
        rank_loss = train_discriminator(discriminator, optimizer_disc, x, edge_index, emb_node2vec, emb_pca, args)
    homo_edge, heter_edge, _ = discriminator(data.x, data.edge_index)


    print('pretrain is done!')

    return emb_node2vec,emb_pca, homo_edge, heter_edge

def sce_loss(x, y, alpha=3):
    x = F.normalize(x, p=2, dim=-1)
    y = F.normalize(y, p=2, dim=-1)

    # loss =  - (x * y).sum(dim=-1)
    # loss = (x_h - y_h).norm(dim=1).pow(alpha)

    loss = (1 - (x * y).sum(dim=-1)).pow_(alpha)

    loss = loss.mean()
    return loss


def train(mask_homo_x,homo_edge, masked_homo_indices,mask_heter_x,heter_edge, masked_heter_indices):
    model.train()
    optimizer.zero_grad()

    recon_11, recon_12, recon_21,recon_22, recon_x = model.enc_dec(mask_homo_x ,homo_edge, mask_heter_x,heter_edge)

    x_init1 = data.x[masked_homo_indices]
    x_rec1 = recon_x[masked_homo_indices]

    x_init2 = data.x[masked_heter_indices]
    x_rec2 = recon_x[masked_heter_indices]

    loss1 = sce_loss(x_init1,x_rec1) + sce_loss(x_init2,x_rec2)


    loss1_f11 = semi_loss(emb_node2vec[masked_homo_indices], recon_11[masked_homo_indices])
    loss1_f12 = semi_loss(emb_node2vec[masked_homo_indices], recon_21[masked_homo_indices])
    loss1_f13 = semi_loss(emb_pca[masked_homo_indices], recon_12[masked_homo_indices])
    loss1_f14 = semi_loss(emb_pca[masked_homo_indices], recon_22[masked_homo_indices])

    loss1_f21 = semi_loss(emb_node2vec[masked_heter_indices], recon_11[masked_heter_indices])
    loss1_f22 = semi_loss(emb_node2vec[masked_heter_indices], recon_21[masked_heter_indices])
    loss1_f23 = semi_loss(emb_pca[masked_heter_indices], recon_12[masked_heter_indices])
    loss1_f24 = semi_loss(emb_pca[masked_heter_indices], recon_22[masked_heter_indices])

    info_loss =loss1 + loss1_f11.mean() + loss1_f12.mean() + loss1_f13.mean() + loss1_f14.mean()
    +loss1_f21.mean() + loss1_f22.mean() + loss1_f23.mean() + loss1_f24.mean()

    info_loss.backward()
    optimizer.step()


    return float(info_loss)


@torch.no_grad()
def test(data):
    model.eval()
    z = model(data.x, data.edge_index)

    acc = label_classification(z, data.y, ratio=0.1)
    nmi, ari, _ = clustering(z, data.y, dataset.num_classes)

    acc_mean = acc.get('F1Mi').get('mean')

    return acc_mean, nmi, ari


def adjust_learning_rate(optimizer, epoch):
    lr = args.lr * (args.lrdec_1 ** (epoch // args.lrdec_2))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def sim(z1: torch.Tensor, z2: torch.Tensor):
    z1 = F.normalize(z1)
    z2 = F.normalize(z2)
    return torch.mm(z1, z2.t())


def semi_loss(z1: torch.Tensor, z2: torch.Tensor):
    f = lambda x: torch.exp(x / args.tau)

    refl_sim = f(sim(z1, z1))

    between_sim = f(sim(z1, z2))

    loss = -torch.log(between_sim.diag() / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))

    return loss


if __name__ == '__main__':
    seed = args.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    device = 'cpu'

    path = osp.join(osp.expanduser('~'), 'datasets', args.dataset)
    dataset = get_dataset(path, args.dataset)
    data = dataset[0]
    data = data.to(device)

    discriminator = New_EdgeDiscriminator(nnodes=data.num_nodes, input_dim=dataset.num_node_features, alpha=0.5,
                                          sparse=False, hidden_dim=128, temperature=1.0).to(device)
    optimizer_disc = torch.optim.Adam(discriminator.parameters(), lr=0.01, weight_decay=5e-4)


    emb_node2vec,emb_pca,homo_edge, heter_edge = pretrain(discriminator, optimizer_disc, data.x, data.edge_index, args)


    student_start = t()
    in_channels, hidden_num, head, out_channels = dataset.num_features, args.hidden_num, args.head, args.out_channels

    emb_size_1 = emb_node2vec.shape[1]
    emb_size_2 = emb_pca.shape[1]

    activation = torch.nn.ELU()

    model = GAE(dataset.num_features, hidden_num, head, out_channels, emb_size_1, emb_size_2, activation, GATConv).to(
        device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    total_loss = []
    accuracy = []
    for epoch in range(1, args.epoch + 1):
        adjust_learning_rate(optimizer, epoch)

        mask_homo_x, masked_homo_indices = mask_feature(data.x, args.edge_p1)

        mask_heter_x, masked_heter_indices = mask_feature(data.x, args.edge_p2)

        info_loss = train(mask_homo_x,homo_edge, masked_homo_indices,mask_heter_x,heter_edge, masked_heter_indices)

    acc, nmi, ari = test(data)
    print(f'Final result: acc: {acc:.4f}, nmi:{nmi:.4f}, ari: {ari:.4f}')
    f = open(args.dataset + ".txt", "a")
    f.write(str(acc) + " " + str(nmi) + " " + str(ari) + "\n")
    f.close()





