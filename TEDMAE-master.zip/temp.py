# mask_edge, mask_index_edge = dropout_edge(data.edge_index, args.edge_p)
#
#
# mask_edge_node = mask_index_edge*data.edge_index[0]
# mask_index_edge_binary = torch.zeros(data.x.shape[0]).to(device)
# mask_index_edge_binary[mask_edge_node] = 1
# mask_index_edge_binary = mask_index_edge_binary.to(bool)
# mask_both_node_edge = mask_index_edge_binary & mask_index_node_binary
# mask_index_node_binary_sole = mask_index_node_binary &(~mask_both_node_edge)
# mask_index_edge_binary_sole  = mask_index_edge_binary &(~mask_both_node_edge)